## Sandboxie Plus installer instructions

### To create Sbie Plus installer environment

1) Install Inno Setup 6.2.2 (installer is located at https://jrsoftware.org/isdl.php#stable)

> Note: this section requires additional steps to be completed, please open a new pull request.

### To create the Sbie Plus installers

The Sbie Plus installer ISS file is [Sandboxie-Plus.iss](Sandboxie-Plus.iss).

> Note: this section requires steps to be completed, please open a new pull request.
